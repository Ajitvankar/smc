<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://www.villageappco.com/village/public/css/style-new.css">
  <title>KIRANA MART TERMS OF USE AGREEMENT</title>
</head>
<body>
  <div class="main">
 <h3 style="text-align: center;margin-bottom: 20px;"><strong>KIRANA MART TERMS OF USE AGREEMENT</strong></h3>
<h5>Last modified: MAY 25, 2020</h5>
<p><strong><u>Acceptance of the Terms of Use</u></strong>. ThisTerms of Use Agreement (the &ldquo;Agreement&rdquo; or &ldquo;Terms of Use&rdquo;) is entered into by and between You and KIRANA MART App. (referred to herein as &ldquo;KIRANA MART&rdquo;, &ldquo;we,&rdquo; &ldquo;our,&rdquo; or &ldquo;us&rdquo;). The following terms and conditions, together with any documents they expressly incorporate by reference, govern your access to and use of KIRANA MART application, including any content, functionality and services offered on or through KIARANA MART application (collectively referred to herein as the &ldquo;App&rdquo;), whether as a guest or a registered user.</p>
<p>PLEASE READ THE TERMS OF USE CAREFULLY BEFORE YOU START TO USE THE APP. <strong>BY USING THE APP OR BY CLICKING TO ACCEPT OR AGREE TO THE TERMS OF USE WHEN THIS OPTION IS MADE AVAILABLE TO YOU, YOU ACCEPT AND AGREE TO BE BOUND AND ABIDE BY THESE TERMS OF USE AND OUR PRIVACY POLICY, INCORPORATED HEREIN BY REFERENCE.</strong> THE TERMS APPLY TO ALL USERS OF THE APP, INCLUDING THOSE WHO ARE SIMPLY NAVIGATING THE APP, OR THOSE WHO REGISTER AN ACCOUNT. IF YOU DO NOT WANT TO AGREE TO THESE TERMS OF USE OR THE PRIVACY POLICY, YOU MUST NOT ACCESS OR USE THE APP.</p>

<p><strong><u>NOTICE OF CHARGE</u></strong><strong>: We provide the best service you just need to pay only one time for sale you product online</strong></p>
<p>Payment made only for shopkeeper</p>
<p>Customer not have to pay any charge</p>

<p><strong><u>NOTICE OF ARBITRATION AGREEMENT AND CLASS ACTION WAIVER</u></strong><strong>: THIS AGREEMENT INCLUDES A BINDING ARBITRATION CLAUSE AND A CLASS ACTION WAIVER, SET FORTH BELOW, WHICH AFFECT YOUR RIGHTS ABOUT RESOLVING ANY DISPUTE WITH THE VILLAGE. PLEASE READ IT CAREFULLY.</strong></p>

<ol>
<li><strong><u>Changes to the Terms of Use</u></strong>.</li>
</ol>
<p>We may revise and update these Terms of Use from time to time in our sole discretion. All changes are effective immediately when we post them and apply to all access to and use of the App thereafter.</p>

<p>Your continued use of the App following the posting of revised Terms of Use means that you accept and agree to the changes. You are expected to periodically check this page so you are aware of any changes, as they are binding on you.</p>

<ol start="2">
<li><strong><u>Privacy Policy. </u></strong></li>
</ol>
<p>For information about the collection and possible use of information and material provided by you, please click on the Privacy Policy link located on the home screen of the App. By using the App, you are consenting to the terms of such Privacy Policy which is incorporated herein.</p>

<p>KIRANA MART Application is provde you facility to sell your product under 25KM range</p>
<p>You can add any no of item in your registered shop</p>
<p>You can add only one shop by your email and mobile number</p>
<p>To deliver product is depend on shopkeeper, we not giving you surity about home delivery</p>

<ol start="5">
<li><strong><u>Eligibility</u></strong><strong>.</strong></li>
</ol>
<ul>
<li>you are 18 years of age or older;</li>
<li>you comply with all laws, rules and regulations in connection with your use of the App;</li>
<li>you have the right and the legal capacity to enter into and abide by these Terms of Use;</li>
<li>you have not been the subject of a complaint, restraining order or any other legal action or offence that involves endangering the safety of others, including without limitation any charges or claims relating to violence, abuse, or neglect; and</li>
<li>youhave not been convicted of any misdemeanor or felony crime of any nature, other than a routine traffic offense.</li>
</ul>

<p>You furthermore acknowledge and agree that KIRANA MART may rely on the Eligibility Conditions representations and warranties as true, and that you will immediately uninstall the App and discontinue your use of the App should you no longer meet any Eligibility Condition.</p>

<ol start="6">
<li><strong><u>Third-Party Payment Processing</u></strong>.</li>
</ol>
<p>Through its App, KIARANA MART APP will provide access to third-party payment processing services to PAYUMONEY that will enable Sitters to collect payments for their Services from Families who have engaged them for such Services. You understand and agree that these payment processing services are not provided by KIRANA MART APP, nor does KIRANA MART APP control, endorse, or make any representations or warranties regarding such third-party payment processing services. <strong>YOU UNDERSTAND AND AGREE THAT USE OF SUCH THIRD-PARTY PAYMENT PROCESSING SERVICES IS AT YOUR OWN RISK, THAT KIRANA MART APP TERMS OF USE AND POLICIES DO NOT APPLY TO SUCH THIRD-PARTY SERVICES, AND THAT KIRANA MART APP IS NOT RESPONSIBLE OR LIABLE IN ANY MANNER FOR SUCH THIRD-PARTY SERVICES AND CONTENT, OR FOR ANY LOSS OR DAMAGE OF ANY SORT INCURRED AS THE RESULT OF THE USE OF THOSE SERVICES, AND KIRANA MART APP HEREBY EXPRESSLY DISCLAIMS, AND YOU HEREBY EXPRESSLY RELEASE KIRANA MART APP FROM, ANY AND ALL LIABILITY WHATSOEVER FOR ANY CONTROVERSIES, CLAIMS, SUITS, INJURIES, LIABILITIES AND/OR DAMAGES ARISING FROM AND/OR IN ANY WAY RELATED TO SUCH THIRD-PARTY SERVICES.</strong></p>
  </div>
</body>
</html>
<style type="text/css">
  .main{
    margin: 5px;
  }
  p {
  	margin-bottom: 20px;
  }
  ul {
  	margin-bottom: 20px;
  }
  ul li {
  	margin-bottom: 20px;
  }
  ol li {
  	margin-bottom: 20px;
  }
  ol {
  	margin-bottom: 20px;
  }
</style><?php /**PATH C:\xampp\htdocs\kirana_mart\resources\views/term-condition.blade.php ENDPATH**/ ?>