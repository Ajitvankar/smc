<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://www.villageappco.com/village/public/css/style-new.css">
  <title>Privacy POLICY</title>
</head>
<body>
  <div class="main">
<h3 style="text-align: center; margin: 0 0 20px;"><strong>KIRANA MART PRIVACY POLICY</strong></h3>
<h5 style="margin: 0 0 20px;">Lastmodified: 25 05, 2020</h5>
<h3><u>Introduction</u></h3>
<p>KIRANA MART App (“we,” “our,” or “us”) respects your privacy and is committed to protecting it through our compliance with this policy.</p>

<p>This policy describes the types of information we may collect from you or that you may provide when using KIARANA MART App (referred to herein as the “App”) and our practices for collecting, using, maintaining, protecting and disclosing that information.</p>

<h5>This policy applies to information we collect:</h5>

<ul>
<li>Through use of our App</li>
<li>In e-mail, text and other electronic messages between you and KIRANA MART.</li>
<li>When you interact with our advertising and applications on third-party apps, websites and services, if those applications or advertising include links to this policy</li>
</ul>
<p>Please read this policy carefully to understand our policies and practices regarding your information and how we will treat it. If you do not agree with our policies and practices, your choice is not to use our App. By accessing or using our App, you agree to this privacy policy. This policy may change from time to time <em>Changes to our Privacy Policy</em></a>). Your continued use of our App or Website after we make changes is deemed to be acceptance of those changes, so please check the policy periodically for updates.</p>

<h3><u>Information We Collect About You and How We Collect It</u></h3>
<p>We collect several types of information from and about users of our App and visitors to our Website, including information:/p>

<ul>
<li>by which you may be personally identified, such as name, postal address, e-mail address, or telephone number, or (“personal information”);</li>
<li>that you provide to us, as more thoroughly described below, and</li>
<li>about your internet connection, the equipment you use to access our App and Website and usage details.</li>
</ul>
<p>We collect this information:</p>

<ul>
<li>Directly from you when you provide it to us.</li>
<li>Automatically as you navigate through the App and Website. Information collected automatically may include usage details, IP addresses and information collected through cookies, web beacons and other tracking technologies.</li>
</ul>

<p><strong><u>Information You Provide to Us.</u></strong> The information we collect on or through our App and Website may include:</p>

<ul>
<li>•Information that you provide when you create an account, create or edit your profile, upload content or comments, complete a registration, or subscribe to the App.</li>
<li>Information that you provide in connection with offering or obtaining the Services provided by the App.</li>
<li>We may also ask you for information when you report a problem with our App or Website.</li>
<li>Records and copies of your correspondence (including e-mail addresses), if you contact us.</li>
<li>Your responses to surveys that we might ask you to complete for research purposes.</li>
</ul>
<p>The types of information we may collect in this manner include basic contact information (e.g. name, email address, mobile number), location, photographs, and credit card and other payment and bank information you provide to us.</p>

<p><strong><u>Information We Collect through Automatic Data Collection Technologies.</u></strong> As you navigate through and interact with our App and Website, we may use automatic data collection technologies to collect certain information about your equipment, browsing actions and patterns, including:</p>

<ul>
<li>Details of your visits to our App, including traffic data, location data, logs and other communication data and the resources that you access and use on the App.</li>
<li>Log information about your use of the App, We do link this automatically collected data to other information we collect about you. We do this for many reasons, including without limitation to improve services, marketing, analytics, and site functionality.</li>
<li>When you download and use our Services, we automatically collect information on the type of device you use and operating system version.</li>
<li>We may also collect third-party contact information if you permit the App to import such information or otherwise upload such information for your use within the App. This information may include, but is not limited to, such third party&rsquo;s name and basic contact info. We use this information only as described in this paragraph.</li>

<h3><u>How We Use Your Information</u></h3>
<p>We use information that we collect about you or that you provide to us, including any personal information:</p>

<ul>
<li>To present our App and its contents to you.</li>
<li>To provide you with information that you request from us.</li>
<li>To respond to your inquiries.</li>
<li>To fulfill any other purpose for which you provide it.</li>
<li>To provide you with notices about your account, including expiration and renewal notices.</li>
<li>To allow you to participate in interactive features on our App.</li>
<li>In any other way we may describe when you provide the information.</li>
<li>For any other purpose with your consent.</li>
</ul>
<p>We may use the information we have collected from you to enable us to display advertisements to our advertisers’ target audiences. Even though we do not disclose your personal information for these purposes without your consent, if you click on or otherwise interact with an advertisement, the advertiser may assume that you meet its target criteria.</p>

<h3><u>Disclosure of Your Information</u></h3>
<p>We may disclose aggregated information about our users, and information that does not identify any individual, without restriction.</p>

<p>We may disclose personal information that we collect or you provide as described in this privacy policy:</p>

<h3><u>Sale of Your Information</u></h3>
<p><strong>KIRANA MART App may sell certain of your information, such as your name, email, mobile number, shop detail, item max used in your area.</strong></p>

<h3><u>Data Security</u></h3>
<p>We have implemented measures designed to secure your personal information from accidental loss and from unauthorized access, use, alteration and disclosure. All information you provide to us is stored on our secure servers behind firewalls.</p>

<p>The safety and security of your information also depends on you. Where we have given you (or where you have chosen) a username and password in order to register for our App, you are responsible for keeping this information confidential. We ask you not to share your username and password with anyone. We urge you to be careful about giving out information in public areas of the App. The information you share in public areas may be viewed by any user of the App.</p>

<p>Unfortunately, the transmission of information via the internet is not completely secure. Although we do our best to protect your personal information, we cannot guarantee the security of your personal information transmitted to our App. Any transmission of personal information is at your own risk. We are not responsible for circumvention of any privacy settings or security measures contained on the App or Website.</p>

<h3><u>Changes to Our Privacy Policy</u></h3>
<p>It is our policy to post any changes we make to our privacy policy on this page with a notice that the privacy policy has been updated on the App. If we make material changes to how we treat our users’ personal information, we will notify you through a notice on the App. The date the privacy policy was last revised is identified at the top of the page. You are responsible for ensuring we have an up-to-date active and deliverable e-mail address for you, and for periodically visiting our App and this privacy policy to check for any changes.</p>

<h3><u>Contact Information</u></h3>
<p>To ask questions or comment about this privacy policy and our privacy practices, contact us at:</p>

<p>kiranamart2020@gmail.com</p>

  </div>
</body>
</html>
<style type="text/css">
  .main{
    margin: 5px;
  }
  p {
  	margin-bottom: 20px;
  }
</style><?php /**PATH C:\xampp\htdocs\kirana_mart\resources\views/privacypolicy.blade.php ENDPATH**/ ?>