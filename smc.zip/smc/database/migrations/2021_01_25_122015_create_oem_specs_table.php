<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOemSpecsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('oem_specs', function (Blueprint $table) {
            $table->id();
            $table->string('name_model');
            $table->string('year_model');
            $table->float('price_list');
            $table->string('availble_color');
            $table->string('mileage');
            $table->string('power');
            $table->string('max_speed');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('oem_specs');
    }
}
