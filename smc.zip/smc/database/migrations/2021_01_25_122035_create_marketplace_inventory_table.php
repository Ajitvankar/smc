<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMarketplaceInventoryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('marketplace_inventory', function (Blueprint $table) {
            $table->id();
            $table->integer('user_id');
            $table->string('kms_odometer');
            $table->string('major_crathes');
            $table->string('original_paint');
            $table->string('number_accident');
            $table->string('number_previous_buyer');
            $table->string('registration_place');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('marketplace_inventory');
    }
}
