<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });
Route::post('login', 'Api\UserController@login');
Route::post('registration', 'Api\UserController@registration');

Route::get('oemList', 'Api\OemController@oemList');
Route::post('oemSearch', 'Api\OemController@oemSearch');

Route::middleware('auth:api')->group(function () {
	Route::post('updateProfile', 'Api\UserController@updateProfile');
	Route::get('deleteAccount', 'Api\UserController@deleteAccount');

	Route::post('addInventory', 'Api\OemController@addInventory');
	Route::post('inventorySearch', 'Api\OemController@inventorySearch');

});