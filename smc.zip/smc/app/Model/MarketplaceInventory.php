<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class MarketplaceInventory extends Model
{
    protected $table = 'marketplace_inventory';
    protected $primaryKey = 'id';
    protected $fillable = ['user_id','kms_odometer','major_crathes','original_paint','number_accident','number_previous_buyer','registration_place'];
}
