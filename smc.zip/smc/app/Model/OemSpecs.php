<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class OemSpecs extends Model
{
    protected $table = 'oem_specs';
    protected $primaryKey = 'id';
    protected $fillable = ['name_model','year_model','price_list','availble_color','mileage','power','max_speed'];
}
