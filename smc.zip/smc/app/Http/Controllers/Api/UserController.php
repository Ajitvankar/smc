<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use App\Model\MarketplaceInventory;
use App\Model\OemSpecs;
use Auth,DB,Storage;

class UserController extends Controller
{
    public function registration(Request $request)
    {
    	$request_all = $request->input();

    	$User = new User();
    	$User->name = $request_all['name'];
    	$User->mobile = $request_all['mobile'];
    	$User->email = $request_all['email'];
    	$User->password = bcrypt($request_all['password']);
    	$User->save();
    	$token = $User->createToken('TutsForWeb')->accessToken;
    	return response()->json(array('token'=>$token,'code'=>200,'message'=>'Registration successfully done','results'=>$User), 200);
    }

    public function login(Request $request)
    {
    	$postdata = $request->all();
        $request_all = $request->input();
        $credentials = [
            'email' => $request->email,
            'password' => $request->password
        ];
        if (auth()->attempt($credentials)) {
        	$user = auth()->user();
        	$token = auth()->user()->createToken('TutsForWeb')->accessToken;
        	return response()->json(array('token'=>$token,'code'=>200,'message'=>'Login successfull','results'=>$user), 200);
        }else{
            return response()->json(array('code'=>100,'message'=>'Login fail','results'=>[]), 200);
        }
    }

    public function updateProfile(Request $request)
    {
        $loginUser = auth()->user();
        $all_param = $request->input();
        if(isset($all_param['password']) AND !empty($all_param['password'])){
            $all_param['password'] = bcrypt($all_param['password']);
        }        
        User::updateOrCreate(['id' => $loginUser->id],$all_param);
        $Users = User::where('id',$loginUser->id)->get()->first();
        return response()->json(array('code'=>200,'message'=>'Profile updated successfully','results'=>$Users), 200);
    }

    public function deleteAccount()
    {
        $loginUser = auth()->user();
        if (Auth::check()) {
           $loginUser->delete();
           return response()->json(array('code'=>200,'message'=>'Account deleted successfully','results'=>[]), 200);
        }
        return response()->json(array('code'=>200,'message'=>'Login user not found','results'=>[]), 200);
    }
}
