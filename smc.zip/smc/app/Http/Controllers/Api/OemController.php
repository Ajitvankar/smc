<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use App\Model\MarketplaceInventory;
use App\Model\OemSpecs;
use Auth,DB,Storage;

class OemController extends Controller
{
    function oemList()
    {
    	$OemSpecs = OemSpecs::get();
    	return response()->json(array('code'=>200,'message'=>'List Of OEM','results'=>$OemSpecs), 200);
    }

    function oemSearch(Request $request)
    {
    	$request_all = $request->input();

    	if(!empty($request_all)){
    		$OemSpecs = OemSpecs::where('name_model','!=','');
    		foreach ($request_all as $key => $value) {
    			$OemSpecs = $OemSpecs->where($key,$value);
    		}
    		$OemSpecs = $OemSpecs->get()->all();
    	}else{
    		$OemSpecs = OemSpecs::get();
    	}    	
    	return response()->json(array('code'=>200,'message'=>'List Of OEM','results'=>$OemSpecs), 200);
    }

    /*Invetory*/
    public function addInventory(Request $request)
    {
    	$loginUser = auth()->user();
    	$request_all = $request->input();

    	$MarketplaceInventory = new MarketplaceInventory();
    	$MarketplaceInventory->user_id = $loginUser->id;
    	$MarketplaceInventory->kms_odometer = $request_all['kms_odometer'];
    	$MarketplaceInventory->major_crathes = $request_all['major_crathes'];
    	$MarketplaceInventory->original_paint = $request_all['original_paint'];
    	$MarketplaceInventory->number_accident = $request_all['number_accident'];
    	$MarketplaceInventory->number_previous_buyer = $request_all['number_previous_buyer'];
    	$MarketplaceInventory->registration_place = $request_all['registration_place'];
    	$MarketplaceInventory->save();

    	return response()->json(array('code'=>200,'message'=>'Invetory successfully added','results'=>$MarketplaceInventory), 200);
    }

    function inventorySearch(Request $request)
    {
    	$request_all = $request->input();

    	if(!empty($request_all)){
    		$MarketplaceInventory = MarketplaceInventory::where('kms_odometer','!=','');
    		foreach ($request_all as $key => $value) {
    			$MarketplaceInventory = $MarketplaceInventory->where($key,$value);
    		}
    		$MarketplaceInventory = $MarketplaceInventory->get()->all();
    	}else{
    		$MarketplaceInventory = MarketplaceInventory::get();
    	}    	
    	return response()->json(array('code'=>200,'message'=>'Search Inventory results','results'=>$MarketplaceInventory), 200);
    }

    // public function updateProfile(Request $request)
    // {
    //     $loginUser = auth()->user();
    //     $all_param = $request->input();       
    //     $MarketplaceInventory = MarketplaceInventory::updateOrCreate(['id' => $all_param['id']],$all_param);
    //     return response()->json(array('code'=>200,'message'=>'Invetory updated successfully','results'=>$MarketplaceInventory), 200);
    // }
}
