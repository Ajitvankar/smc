<?php
// Send push notification
function push_notification_android($device_id,$data){

//API URL of FCM
$url = 'https://fcm.googleapis.com/fcm/send';

/*api_key available in:
Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key*/   
$api_key = 'AAAAv5Ex5hQ:APA91bHpY4PNbLUWBjTFwFKa4oYpGuJ1l8Mj1LpOrdpOmz9u8H2WXfdjwjMgBcIHoJ1Opx4yt-BsphUjpr-32sCMr4niYaixYZ4x8N7f6kdMfga_dQvKS6oJBVcFn7uHc5L5uJsMERjT';
            
$fields = array (
    'registration_ids' => array($device_id),
    'notification'=>$data
);
//header includes Content type and api key
$headers = array(
    'Content-Type:application/json',
    'Authorization:key='.$api_key
);
            
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
$result = curl_exec($ch);
if ($result === FALSE) {
    die('FCM Send Error: ' . curl_error($ch));
}
curl_close($ch);
return $result;
}
function sendPushNotificationIos($deviceToken=array(),$data=array())
{
    $pemfile = public_path().'/images/Certificates.pem';
   // $deviceToken = '215077a00effe4816621304f0bdbc62dcf7ab5e94074e7ff99f3233a0fa605fb'; //  iPad 5s Gold prod
    $passphrase = '';
    $message = $data['message'];
    $gameId = (isset($data['game_id']) ? $data['game_id'] : '');
    $ctx = stream_context_create();
    stream_context_set_option($ctx, 'ssl', 'local_cert', $pemfile); // Pem file to generated // openssl pkcs12 -in pushcert.p12 -out pushcert.pem -nodes -clcerts // .p12 private key generated from Apple Developer Account
    stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
    $fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx); // production
    // $fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx); // developement

    // echo "<p>Connection Open</p>";
    if(!$fp){
        // echo "<p>Failed to connect!<br />Error Number: " . $err . " <br />Code: " . $errstrn . "</p>";
        return;
    } else {
        // echo "<p>Sending notification!</p>";    
    }

    $data['aps']['alert']=$message;
    $data['aps']['sound']='push_default.wav';
    if(!empty($gameId)){
        $data['aps']['game_id']=$gameId;
    }

    if(isset($data['notification_type']))
    {
        $data['aps']['notification_type']=$data['notification_type'];
    }

    $body['aps']=$data['aps'];
    // $body['aps'] = array('alert' => $message,'sound' => 'default','extra1'=>'10','extra2'=>'value');
    $payload = json_encode($body);
    
    //for multiple
    if(!empty($deviceToken)){
        foreach ($deviceToken as $key => $value) {
            if($value != '123456')
            {
                $msg = chr(0) . pack('n', 32) . pack('H*', $value) . pack('n', strlen($payload)) . $payload;
                $result = fwrite($fp, $msg, strlen($msg));    
            }
        }    
    }
    

    // $msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
    // $result = fwrite($fp, $msg, strlen($msg));
    
    // if (!$result)
    //     echo '<p>Message not delivered ' . PHP_EOL . '!</p>';
    // else
    //     echo '<p>Message successfully delivered ' . PHP_EOL . '!</p>';
    
    fclose($fp);
}

